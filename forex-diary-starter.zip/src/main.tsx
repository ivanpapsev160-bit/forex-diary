import React from 'react';
import { createRoot } from 'react-dom/client';
import './styles.css';

const stats = [
  ['Баланс', '$10,250', '+2.5%'],
  ['Прибыль', '$1,240', '+12.1%'],
  ['Win Rate', '68%', '+4.2%'],
];

function App() {
  return (
    <main className="app">
      <header className="topbar">
        <div>
          <div className="eyebrow">FOREX DIARY</div>
          <h1>Добро пожаловать</h1>
          <p>Ваш торговый день под контролем.</p>
        </div>
        <button className="avatar">FD</button>
      </header>

      <section className="hero">
        <div>
          <span>Текущий баланс</span>
          <strong>$10,250.00</strong>
          <small>+ $240.00 сегодня</small>
        </div>
        <div className="trend">↗</div>
      </section>

      <section className="stats">
        {stats.map(([label, value, change]) => (
          <article className="card" key={label}>
            <span>{label}</span>
            <strong>{value}</strong>
            <small>{change}</small>
          </article>
        ))}
      </section>

      <section className="section">
        <div className="section-title">
          <h2>Быстрые действия</h2>
        </div>
        <button className="primary">＋ Добавить сделку</button>
      </section>

      <section className="section">
        <div className="section-title">
          <h2>Сегодня</h2>
          <span>6 октября</span>
        </div>
        <div className="empty">
          <div className="empty-icon">↗</div>
          <strong>Сделок пока нет</strong>
          <p>Добавьте первую сделку, чтобы начать вести дневник.</p>
        </div>
      </section>

      <nav className="bottom-nav">
        <button className="active">⌂<span>Главная</span></button>
        <button>▣<span>Сделки</span></button>
        <button>◔<span>Статистика</span></button>
        <button>⚙<span>Настройки</span></button>
      </nav>
    </main>
  );
}

createRoot(document.getElementById('root')!).render(
  <React.StrictMode><App /></React.StrictMode>
);